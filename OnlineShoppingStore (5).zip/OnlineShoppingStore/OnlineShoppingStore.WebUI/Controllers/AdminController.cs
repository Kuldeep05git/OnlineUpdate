﻿using OnlineShoppingStore.Domain.Abstract;
using OnlineShoppingStore.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineShoppingStore.WebUI.Controllers
{
    public class AdminController : Controller
    {
        private IProductRepository repository;
        public AdminController(IProductRepository repo)
        {
            repository = repo;

        }
        public ActionResult Index()
        {
            return View(repository.Products);
        }
        public ActionResult Edit(int id)
        {
            //int productid = Convert.ToInt32(collection["id"]);
            Product product = repository.Products.Where(x => x.PrductId == id).FirstOrDefault();
            return View(product);
        }
        [HttpPost]
        public ActionResult Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                repository.SaveProduct(product);
                TempData["message"] = string.Format("{0} has been saved successfully", product.Name);
                return RedirectToAction("Index");
            }
            else
            {
                //If somthing wrong with data
                return View(product);
            }
        }
    }
}
