﻿using OnlineShoppingStore.Domain.Concrete.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingStore.Domain.Abstract
{
    public interface IAuthenticate
    {
        IEnumerable<User> Users { get; }
        bool Authenticate(string username, string password);
       // bool Logout();
        bool ChangePassword(string Oldpwd, string NewPwd);

        
    }
}
