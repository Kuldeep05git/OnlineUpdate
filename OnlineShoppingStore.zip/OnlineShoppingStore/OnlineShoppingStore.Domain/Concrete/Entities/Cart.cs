﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingStore.Domain.Entities
{
    public class Cart
    {
        private List<CartLine> linecollection = new List<CartLine>();
        public void AddItem(Product product, int quantity)
        {
            CartLine line = linecollection.Where(p => p.product == product).FirstOrDefault();
            if (line == null)
            {
                linecollection.Add(new CartLine { product = product, quantity = quantity });
            }
            else
            {
                line.quantity += quantity;
            }
        }
        public void RemoveLine(Product product)
        {
            linecollection.RemoveAll(p => p.product == product);
        }
        public decimal ComputeTotalValue()
        {
            return linecollection.Sum(p => p.product.Price * p.quantity);
        }
        public IEnumerable<CartLine> Lines
        {
            get
            {
                return linecollection;
            }
        }
        public void Clear()
        {
            linecollection.Clear();
        }
    }
}
