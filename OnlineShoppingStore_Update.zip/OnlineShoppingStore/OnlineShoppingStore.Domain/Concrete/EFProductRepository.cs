﻿using OnlineShoppingStore.Domain.Abstract;
using OnlineShoppingStore.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingStore.Domain.Concrete
{
    public class EFProductRepository:IProductRepository
    {
        private readonly EFDbContext context = new EFDbContext();
        //Getting Product details from database
        public IEnumerable<Product> Products
        {
            get { return context.Products; }
        }
        //Save Value in Database

        public void SaveProduct(Product product)
        {
            context.Products.Attach(product);
            context.Entry(product).State = EntityState.Modified;           
            context.SaveChanges();
        }


        public void DeleteRow(Product product)
        {
            context.Products.Remove(product);
            context.SaveChanges();
        }


        public void AddNewProduct(Product product)
        {
            context.Products.Add(product);
            context.SaveChanges();
        }
    }
}
