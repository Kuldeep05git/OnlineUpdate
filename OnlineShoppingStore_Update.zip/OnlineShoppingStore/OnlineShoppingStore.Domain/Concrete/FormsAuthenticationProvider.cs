﻿using OnlineShoppingStore.Domain.Abstract;
using OnlineShoppingStore.Domain.Concrete.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingStore.Domain.Concrete
{
    public class FormsAuthenticationProvider:IAuthenticate
    {
        private readonly EFDbContext context = new EFDbContext();
        public bool Authenticate(string username, string password)
        {
            var user = context.Users.Where(x => x.UserName == username && x.Password == password).FirstOrDefault();
            if (user == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool Logout()
        {
            return true;
        }


        public bool ChangePassword(string password)
        {
            var user = context.Users.Where(x => x.UserName == username && x.Password == password).FirstOrDefault();
        }
    }
}
